
<div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h4 class="mt-4"><?php echo $titulo; ?></h4>

                        <div class="">
                            <p>
                         
                                <a href="<?php echo base_url(); ?>/cajas" class="btn btn-outline-warning   "> Unidades </a>
                            </p>
                        </div>

                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                DataTable Example
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                        <th>Id</th>
                                            <th>numero de caja</th>
                                            <th>Nombre</th>
                                            <th>Folio</th>
                                            <th>Reingresar</th>
                              
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php 
                                    foreach ($datos as $dato){  ?>
                                   <tr>
                                   <td> <?php echo $dato['id']; ?>  </td>
                                    <td> <?php echo $dato['numero_caja']; ?> </td>
                                    <td> <?php echo $dato['nombre']; ?> </td>
                                    <td> <?php echo $dato['folio']; ?> </td>
                                    <td>   
                                        <a href="<?php echo base_url().'/cajas/reingresar/'.$dato['id']; ?>" 
                                        class="btn btn-warning"> <i class="fas fa-arrow-alt-circle-up"></i> </a> 
                                    </td>
                    

                                   </tr>
                                  
                                     <?php  } ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
 