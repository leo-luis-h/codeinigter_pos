
<div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h4 class="mt-4"><?php echo $titulo; ?></h4>
                  
                           <?php  if (isset($validation)){ ?>
                            <div class="alert alert-danger">
                            <?php  echo $validation->listErrors(); ?>
                            </div>
                            <?php }?>
                        <form  method="post" action="<?php echo base_url(); ?>/cajas/insertar">
                        <?php csrf_field(); ?>
                        <div class="form-group">
                        <div class="row">
                                 <div class="col-12 col-sm-6">
                                     <label for="nombre">nombre</label>
                                     <input type="text" class="form-control" placeholder="nombre" id="nombre" name="nombre" autofocus required>
                                  </div>

                                 <div class="col-12 col-sm-6">
                                    <label for="numero_caja">Numero de caja</label>
                                    <input type="number" class="form-control" placeholder="nmero de caja" id="numero_caja" name="numero_caja" required>
                                 </div>

                                 <div class="col-12 col-sm-6">
                                    <label for="folio">folio</label>
                                    <input type="number" class="form-control" placeholder="folio" id="folio" name="folio" required>
                                 </div>


                                 <div class="col-12 col-sm-6 mt-2">
                                <a href="<?php echo base_url();?>/cajas" class="btn btn-primary"> Regresar </a>
                                 <button type="submit" class="btn btn-success">Guardar</button>

                                 </div>

                            </div>
                        </div>
                       </form>

                        </div>
                    </div>
                </main>
 </div>