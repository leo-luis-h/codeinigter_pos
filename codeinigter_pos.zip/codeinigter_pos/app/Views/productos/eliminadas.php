
<div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h4 class="mt-4"><?php echo $titulo; ?></h4>

                        <div class="">
                            <p>
                         
                                <a href="<?php echo base_url(); ?>/productos" class="btn btn-outline-warning   "> productos </a>
                            </p>
                        </div>

                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                DataTable Example
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                             <th>Id</th>
                                            <th>Codigo</th>
                                            <th>Nombre</th>
                                            <th>Precio</th>
                                            <th>stock</th>
                                            <th>reingresar</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php 
                                    foreach ($datos as $dato){  ?>
                                   <tr>
                                   <td> <?php echo $dato['id']; ?>  </td>
                                    <td> <?php echo $dato['codigo']; ?> </td>
                                    <td> <?php echo $dato['nombre']; ?> </td>
                                    <td> <?php echo $dato['precio_venta']; ?> </td>
                                    <td> <?php echo $dato['stock_minimo']; ?> </td>
                                    <td> 
                                    <a href="<?php echo base_url().'/productos/reingresar/'.$dato['id']; ?>" 
                                        class="btn btn-warning"> <i class="fas fa-arrow-alt-circle-up"></i> </a> 
                                    </td>
                    

                                   </tr>
                                  
                                     <?php  } ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
 