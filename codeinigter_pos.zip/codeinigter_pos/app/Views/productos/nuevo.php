
<div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h4 class="mt-4"><?php echo $titulo; ?></h4>
                        <?php \Config\Services::validation()->listErrors(); ?>
                        <form  method="post" action="<?php echo base_url(); ?>/productos/insertar">
                        <?php csrf_field(); ?>
                        <div class="form-group">
                            <div class="row">
                                 <div class="col-12 col-sm-2">
                                     <label for="codigo">Codigo</label>
                                     <input type="text" class="form-control" placeholder="codigo" id="codigo" name="codigo" autofocus required>
                                  </div>

                                 <div class="col-12 col-sm-4">
                                    <label for="nombre">nombre</label>
                                    <input type="text" class="form-control" placeholder="nombre" id="nombre" name="nombre"required>
                                 </div>

                                 <div class="col-12 col-sm-3">
                                    <label for="precio_venta">precio de venta </label>
                                    <input type="text" class="form-control" placeholder="precio de venta" id="precio_venta" name="precio_venta"required>
                                 </div>

                                 <div class="col-12 col-sm-3">
                                    <label for="prec_compra">precio de compra </label>
                                    <input type="text" class="form-control" placeholder="precio de compra" id="prec_compra" name="prec_compra"required>
                                 </div>


                                 </div>

                            </div>
                        </div>

                        <div class="form-group container">
                            <div class="row">

                            <div class="col-12 col-sm-3  ">
                                    <label for="stock_minimo">Stock minimo </label>
                                    <input type="text" class="form-control" placeholder="stock_minimo" id="stock_minimo" name="stock_minimo"required>
                            </div>


                                 <div class="col-12 col-sm-2">
                                     <label for="codigo">unidades</label>
                                    <select  class="form-control" name="id_unidad" id="id_unidad">
                                        <option value="">Seleccionar unidad</option>
                                        <?php foreach($unidades as $unidad){ ?>
                                            <option value="<?php echo $unidad['id'];?>"> <?php  echo $unidad['nombre']; ?>
                                           </option>       

                                   <?php     } ?>
                                    </select>
                                  </div>
                                  
                                  <div class="col-12 col-sm-2">
                                     <label for="codigo">categoria</label>
                                    <select  class="form-control" name="id_categoria" id="id_categoria">
                                        <option value="">Seleccionar categoria</option>
                                     
                                        
                                        <?php foreach($categorias as $categoria){ ?>
                                            <option value="<?php echo $categoria['id'];?>"> <?php  echo $categoria['nombre']; ?>
                                           </option>       

                                   <?php     } ?>
                                    </select>
                                  </div>

                                  <div class="col-12 col-sm-1">
                                     <label name="inventariable" id="inventariable"  for="inventariable">inventariable</label>
                                    <select  class="form-control" name="inventariable" id="inventariable">
                                        <option value="1">si</option>
                                        <option value="0">no</option>
                                    </select>
                                  </div>
                             

                                 <div class="col-12 col-sm-6 mt-2">
                                <a href="<?php echo base_url();?>/productos" class="btn btn-primary"> Regresar </a>
                                 <button type="submit" class="btn btn-success">Guardar</button>

                                 </div>

                            </div>
                        </div>

                       </form>

                        </div>
                    </div>
                </main>
 </div>