
<div id="layoutSidenav_content">
          <div class="container">
          <form  class="container"  method="post" action="<?php echo base_url(); ?>/configuracion/actualizar">
                        <?php csrf_field(); ?>
                        <div class="form-group">
                            <div class="row">
                                 <div class="col-12 col-sm-6">
                                     <label for="nombre">nombre de la tienda</label>
                                     <input type="text" class="form-control" placeholder="tienda_nombre" id="tienda_nombre" name="tienda_nombre" value="<?php echo $nombre['valor']; ?>" autofocus required>
                                  </div>

                                 <div class="col-12 col-sm-6">
                                    <label for="nombre_corto">RFC</label>
                                    <input type="text" class="form-control" placeholder="rfc" id="tienda_rfc" name="tienda_rfc" value="<?php echo $rfc['valor']; ?>"  required>
                                 </div>
                             
                            </div>
                        </div>


                        <div class="form-group">
                            <div class="row">
                                 <div class="col-12 col-sm-6">
                                     <label for="nombre">telefono de la tienda</label>
                                     <input type="text" class="form-control" placeholder="tienda_telefono" id="tienda_telefono" name="tienda_telefono" value="<?php echo $telefono['valor']; ?>" autofocus required>
                                  </div>

                                 <div class="col-12 col-sm-6">
                                    <label for="nombre_corto">correo de la tienda</label>
                                    <input type="text" class="form-control" placeholder="tienda_email" id="tienda_email" name="tienda_email" value="<?php echo $email['valor']; ?>" required>
                                 </div>
                             
                            </div>
                        </div>


                        <div class="form-group">
                            <div class="row">
                            

                                 <div class="col-12 col-sm-6">
                                    <label for="nombre_corto">direccion de la tienda</label>
                                    <input type="text" class="form-control" placeholder="tienda_direccion" id="tienda_direccion" name="tienda_direccion" value="<?php echo $direccion['valor']; ?>" required>
                                 </div>
                             
                                 <div class="col-12 col-sm-6">
                                     <label for="nombre">Tienda leyenda</label>
                                     <input type="a" class="form-control" placeholder="tienda_leyenda" id="tienda_leyenda" name="tienda_leyenda" value="<?php echo $leyenda['valor']; ?>" autofocus required>
                                  </div>

                            </div>
                        </div>

                        <div class="col-12 col-sm-6 mt-2">
                                <a href="<?php echo base_url();?>/configuracion" class="btn btn-primary"> Regresar </a>
                                 <button type="submit" class="btn btn-success">Guardar</button>

                                 </div>


                       </form>
          </div>
 
                <!-- Modal -->
<div class="modal" id="modal-confirma" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Eliminar registro</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
     <p>
        ¿Desea eliminar este registro?
     </p>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
        <a  class="btn btn-danger btn-ok">Eliminar</a>
      </div>
    </div>
  </div>
</div>