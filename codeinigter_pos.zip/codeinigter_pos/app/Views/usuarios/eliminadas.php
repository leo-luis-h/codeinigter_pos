
<div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h4 class="mt-4"><?php echo $titulo; ?></h4>

                        <div class="">
                            <p>
                         
                                <a href="<?php echo base_url(); ?>/usuarios" class="btn btn-outline-warning   "> Unidades </a>
                            </p>
                        </div>

                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                DataTable Example
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Nombre</th>
                                            <th>Nombre corto</th>
                                            <th>Reingresar</th>
    
                              
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php 
                                    foreach ($datos as $dato){  ?>
                                   <tr>
                                    <td> <?php echo $dato['id']; ?>  </td>
                                    <td> <?php echo $dato['nombre']; ?> </td>
                                    <td> <?php echo $dato['nombre_corto']; ?> </td>
                                    <td>   
                                        <a href="<?php echo base_url().'/usuarios/reingresar/'.$dato['id']; ?>" 
                                        class="btn btn-warning"> <i class="fas fa-arrow-alt-circle-up"></i> </a> 
                                    </td>
                    

                                   </tr>
                                  
                                     <?php  } ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
 