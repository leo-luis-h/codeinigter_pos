
<div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h4 class="mt-4"><?php echo $titulo; ?></h4>

                        <form  method="post" action="<?php echo base_url(); ?>/usuarios/actualiza_password">
              
                        <div class="form-group">
                            <div class="row">
                            
                            
                         

                            <div class="col-12 col-sm-6">
                                    <label for="password">password</label>
                                    <input type="password" class="form-control" placeholder="password" id="password" name="password"required autofocus  >
                                 </div>
                            
            
                    
                                 <div class="col-12 col-sm-6">
                                    <label for="password">confirma password</label>
                                    <input type="password" class="form-control" placeholder="confirma contraseña" id="confirma" name="confirma"required   >
                                 </div>
                            
            
                                 </div> 

                                
                                  
                                 <div class="col-12 col-sm-6 mt-2">
                                <a href="<?php echo base_url();?>/usuarios" class="btn btn-primary"> Regresar </a>
                                 <button type="submit" class="btn btn-success">Guardar</button>

                                 </div>
                        </div>
                       </form>

                       <div>
                            
                            <?php if(isset($data['mensaje'])){  ?>
                                <div class="alert alert-info">
                                <?php echo $data['mensaje']; ?> 
                                </div>
                                <?php   }  ?>
                        
                        </div>

                        </div>
                    </div>
                </main>
 </div>