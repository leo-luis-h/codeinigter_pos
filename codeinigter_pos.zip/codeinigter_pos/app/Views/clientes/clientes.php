
<div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h4 class="mt-4"><?php echo $titulo; ?></h4>

                        <div class="">
                            <p>
                                <a href="<?php echo base_url(); ?>/clientes/nuevo" class="btn btn-outline-info"> Agregar </a>
                                <a href="<?php echo base_url(); ?>/clientes/eliminadas" class="btn btn-outline-warning   "> Eliminados </a>
                            </p>
                        </div>

                        <div class="card mb-4">
                            <div class="card-header">
                                <i class="fas fa-table me-1"></i>
                                DataTable Example
                            </div>
                            <div class="card-body">
                                <table id="datatablesSimple">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>nombre</th>
                                            <th>direccion</th>
                                            <th>telefono</th>
                                            <th>correo</th>
                                            <th>Editar</th>
                                            <th>Eliminar</th>
                              
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php 
                                    foreach ($datos as $dato){  ?>
                                   <tr>
                                    <td> <?php echo $dato['id']; ?>  </td>
                                    <td> <?php echo $dato['nombre']; ?> </td>
                                    <td> <?php echo $dato['direccion']; ?> </td>
                                    <td> <?php echo $dato['telefono']; ?> </td>
                                    <td> <?php echo $dato['correo']; ?> </td>
                                   
                                    <td>   
                                    <a href="<?php echo base_url().'/clientes/editar/'.$dato['id']; ?>" 
                                        class="btn btn-warning"> <i class="fas fa-pencil-alt"></i> </a> 
                                    </td>

                                    <td>   
                                        <a  href="<?php echo base_url().'/clientes/eliminar/'.$dato['id']; ?>" 
                                          class="btn btn-danger"> <i class="fas fa-trash"></i> </a> 
                                    </td>

                                   </tr>
                                  
                                     <?php  } ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
 
  