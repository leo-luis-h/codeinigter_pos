
<div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <h4 class="mt-4"><?php echo $titulo; ?></h4>
                        <?php \Config\Services::validation()->listErrors(); ?>
                        <form  method="post" action="<?php echo base_url(); ?>/clientes/insertar">
                        <?php csrf_field(); ?>
                        <div class="form-group">
                            <div class="row">
                            <div class="col-12 col-sm-3">
                                    <label for="nombre">nombre</label>
                                    <input type="text" class="form-control" placeholder="nombre" id="nombre" name="nombre"  required>
                                 </div>

                                 <div class="col-12 col-sm-3">
                                    <label for="direccion">direccion </label>
                                    <input type="text" class="form-control" placeholder="direccion" id="direccion" name="direccion" required>
                                 </div>

                                 <div class="col-12 col-sm-3">
                                    <label for="telefono">Telefono </label>
                                    <input type="text" class="form-control" placeholder="telefono" id="telefono" name="telefono" required>
                                 </div>

                                 <div class="col-12 col-sm-3">
                                    <label for="correo">correo </label>
                                    <input type="text" class="form-control" placeholder="correo" id="correo" name="correo" required>
                                 </div> 


                                 </div>

                            </div>
                        </div>

                                 <div class="col-12 col-sm-6 mt-2">
                                <a href="<?php echo base_url();?>/clientes" class="btn btn-primary"> Regresar </a>
                                 <button type="submit" class="btn btn-success">Guardar</button>

                                 </div>

                            </div>
                        </div>

                       </form>

                        </div>
                    </div>
                </main>
 </div>