<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (is_file(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Usuarios');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
//$routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default

$routes->get('/', 'Usuarios::login');

// unidades.
$routes->get('/unidades', 'Unidades::index');
$routes->get('/unidades/nuevo', 'Unidades::nuevo');
$routes->match(['get', 'post'], 'unidades/insertar', 'Unidades::insertar');
$routes->add('/unidades/editar/(:num)', 'Unidades::editar/$1');
$routes->match(['get', 'post'], 'unidades/actualizar', 'Unidades::actualizar');
$routes->add('/unidades/eliminar/(:num)', 'Unidades::eliminar/$1');
$routes->get('/unidades/eliminadas', 'Unidades::eliminadas');
$routes->add('/unidades/reingresar/(:num)', 'Unidades::reingresar/$1');

// categorias.
$routes->get('/categorias', 'Categorias::index');
$routes->get('/categorias/nuevo', 'Categorias::nuevo');
$routes->match(['get', 'post'], 'categorias/insertar', 'Categorias::insertar');
$routes->add('/categorias/editar/(:num)', 'Categorias::editar/$1');
$routes->match(['get', 'post'], 'categorias/actualizar', 'Categorias::actualizar');
$routes->add('/categorias/eliminar/(:num)', 'Categorias::eliminar/$1');
$routes->get('/categorias/eliminadas', 'Categorias::eliminadas');
$routes->add('/categorias/reingresar/(:num)', 'Categorias::reingresar/$1');


// productos.
$routes->get('/productos', 'Productos::index');
$routes->get('/productos/nuevo', 'Productos::nuevo');
$routes->match(['get', 'post'], 'productos/insertar', 'Productos::insertar');
$routes->add('/productos/editar/(:num)', 'Productos::editar/$1');
$routes->match(['get', 'post'], 'productos/actualizar', 'Productos::actualizar');
$routes->add('/productos/eliminar/(:num)', 'Productos::eliminar/$1');
$routes->get('/productos/eliminadas', 'Productos::eliminadas');
$routes->add('/productos/reingresar/(:num)', 'Productos::reingresar/$1');


// clientes.
$routes->get('/clientes', 'Clientes::index');
$routes->get('/clientes/nuevo', 'Clientes::nuevo');
$routes->match(['get', 'post'], 'clientes/insertar', 'Clientes::insertar');
$routes->add('/clientes/editar/(:num)', 'Clientes::editar/$1');
$routes->match(['get', 'post'], 'clientes/actualizar', 'Clientes::actualizar');
$routes->add('/clientes/eliminar/(:num)', 'Clientes::eliminar/$1');
$routes->get('/clientes/eliminadas', 'Clientes::eliminadas');
$routes->add('/clientes/reingresar/(:num)', 'Clientes::reingresar/$1');


// configuracion.
$routes->get('/configuracion', 'Configuracion::index');
$routes->get('/configuracion/nuevo', 'Configuracion::nuevo');
$routes->match(['get', 'post'], 'configuracion/insertar', 'Configuracion::insertar');
$routes->add('/configuracion/editar/(:num)', 'Configuracion::editar/$1');
$routes->match(['get', 'post'], 'configuracion/actualizar', 'Configuracion::actualizar');
$routes->add('/configuracion/eliminar/(:num)', 'Configuracion::eliminar/$1');
$routes->get('/configuracion/eliminadas', 'Configuracion::eliminadas');
$routes->add('/configuracion/reingresar/(:num)', 'Configuracion::reingresar/$1');


// cajas.
$routes->get('/cajas', 'Cajas::index');
$routes->get('/cajas/nuevo', 'Cajas::nuevo');
$routes->match(['get', 'post'], 'cajas/insertar', 'Cajas::insertar');
$routes->add('/cajas/editar/(:num)', 'Cajas::editar/$1');
$routes->match(['get', 'post'], 'cajas/actualizar', 'Cajas::actualizar');
$routes->add('/cajas/eliminar/(:num)', 'Cajas::eliminar/$1');
$routes->get('/cajas/eliminadas', 'Cajas::eliminadas');
$routes->add('/cajas/reingresar/(:num)', 'Cajas::reingresar/$1');


// usuarios.
$routes->get('/usuarios', 'Usuarios::index');
$routes->get('/usuarios/nuevo', 'Usuarios::nuevo');
$routes->match(['get', 'post'], 'usuarios/insertar', 'Usuarios::insertar');
$routes->add('/usuarios/editar/(:num)', 'Usuarios::editar/$1');
$routes->match(['get', 'post'], 'usuarios/actualizar', 'Usuarios::actualizar');

$routes->match(['get', 'post'], 'usuarios/valida', 'Usuarios::valida');
$routes->match(['get', 'post'], 'usuarios/logout', 'Usuarios::logout');

$routes->match(['get', 'post'], 'usuarios/cambia_password', 'Usuarios::cambia_password'); //cambiar contraseña
$routes->match(['get', 'post'], 'usuarios/actualiza_password', 'Usuarios::actualiza_password'); //cambiar contraseña

$routes->add('/usuarios/eliminar/(:num)', 'Usuarios::eliminar/$1');
$routes->get('/usuarios/eliminadas', 'Usuarios::eliminadas');
$routes->add('/usuarios/reingresar/(:num)', 'UsuariUsuariosreingresar/$1');



// roles.
$routes->get('/roles', 'Roles::index');
$routes->get('/roles/nuevo', 'Roles::nuevo');
$routes->match(['get', 'post'], 'roles/insertar', 'Roles::insertar');
$routes->add('/roles/editar/(:num)', 'Roles::editar/$1');
$routes->match(['get', 'post'], 'roles/actualizar', 'Roles::actualizar');
$routes->add('/roles/eliminar/(:num)', 'Roles::eliminar/$1');
$routes->get('/roles/eliminadas', 'Roles::eliminadas');
$routes->add('/roles/reingresar/(:num)', 'Roles::reingresar/$1');



/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}
