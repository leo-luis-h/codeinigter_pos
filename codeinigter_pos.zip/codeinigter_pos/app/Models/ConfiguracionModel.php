<?php

namespace App\models; #ruta de este archivo

use CodeIgniter\Model;

class ConfiguracionModel extends Model {


    #https://www.codeigniter.com/user_guide/models/model.html

    protected $table      = 'configuracion';            #nombre de la tabla
    protected $primaryKey = 'id';                  #nombre del campo de la llave primaria

    protected $useAutoIncrement = true;            #ai

    protected $returnType     = 'array';          #de que forma va a retornar cuando se hagan consultas
    protected $useSoftDeletes = false;            #pregunta si se va a usar eliminación de filas

    protected $allowedFields = ['nombre', 'valor'];  #los demas campos de la tabla            #tipo de fecha que se usa
    #protected $deletedField  = 'deleted_at';       #se crea un campo que guarda la fecha de eliminacion

    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;

}

?>