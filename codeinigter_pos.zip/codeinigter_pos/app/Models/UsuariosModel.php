<?php

namespace App\models; #ruta de este archivo

use CodeIgniter\Model;

class UsuariosModel extends Model {


    #https://www.codeigniter.com/user_guide/models/model.html

    protected $table      = 'usuarios';            #nombre de la tabla
    protected $primaryKey = 'id';                  #nombre del campo de la llave primaria

    protected $useAutoIncrement = true;            #ai

    protected $returnType     = 'array';          #de que forma va a retornar cuando se hagan consultas
    protected $useSoftDeletes = false;            #pregunta si se va a usar eliminación de filas

    protected $allowedFields = ['usuario', 'password', 'nombre', 'id_caja', 'id_rol', 'activo'];  #los demas campos de la tabla
    protected $useTimestamps = true;                #tipo de fecha que se usa
    protected $createdField  = 'fecha_alta';        #se crea un campo que guarda la fecha de creacion
    protected $updatedField  = 'fecha_edit';#se crea un campo que guarda la fecha de modificacion
    #protected $deletedField  = 'deleted_at';       #se crea un campo que guarda la fecha de eliminacion

    protected $validationRules    = [];
    protected $validationMessages = [];
    protected $skipValidation     = false;

}

?>