<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UsuariosModel;
use App\Models\CajasModel;
use App\Models\RolesModel;


class Usuarios extends BaseController
{

    protected $usuarios, $cajas, $roles;
    protected $reglasLogin, $reglasCambia;

    public function __construct(){
        $this->usuarios = new UsuariosModel();
        $this->cajas = new CajasModel();
        $this->roles = new RolesModel();

        helper(['form']);

    }

    function index($activo =1){
        $cajas = $this->cajas->where('activo', 1)->findAll();   #consulta para traer todas las usuarios activas, en la misma linea se ejecuta
        $roles = $this->roles->where('activo', 1)->findAll();   #consulta para traer todas las usuarios activas, en la misma linea se ejecuta
        $usuarios = $this->usuarios->where('activo', 1)->findAll();   #consulta para traer todas las usuarios activas, en la misma linea se ejecuta
        
        $data = ['titulo' => 'Usuarios', 'datos' => $usuarios, 'cajas' => $cajas , 'roles' => $roles];

        echo view('header');
        echo view('usuarios/usuarios', $data); #mandamos la informacion a la vista usuarios.php
        echo view('footer');

    }
    

    function nuevo(){

        $cajas = $this->cajas->where('activo', 1)->findAll();
        $roles = $this->roles->where('activo', 1)->findAll();

        $data = ['titulo' => 'Agregar usuario', 'cajas' =>$cajas , 'roles' =>$roles];

        echo view('header');
        echo view('usuarios/nuevo', $data); #mandamos la informacion a la vista usuarios.php
        echo view('footer');

    }
  
    function insertar(){
       if($this->request->getMethod() == 'post'){

        $hash= password_hash($this->request->getPost('password') , PASSWORD_DEFAULT);

       $this->usuarios->save([
        'usuario' => $this->request->getPost('usuario'),
        'password' => $hash,
        'nombre' => $this->request->getPost('nombre'),
         'id_caja' => $this->request->getPost('id_caja'),
         'id_rol' => $this->request->getPost('id_rol'),
         'ACTIVO' => 1
         ]);

       return redirect()->to(base_url().'/usuarios');

       }else{
        $data = ['titulo' => 'Agregar usuario' ];

        echo view('header');
        echo view('usuarios/nuevo', $data); #mandamos la informacion a la vista usuarios.php
        echo view('footer');
       }
       
    }


    function editar($id){
        $cajas = $this->cajas->where('activo', 1)->findAll();   #consulta para traer todas las usuarios activas, en la misma linea se ejecuta
        $roles = $this->roles->where('activo', 1)->findAll(); 
        $usuario = $this->usuarios->where('id', $id)->first(); #first busca el primer registro
        $data = ['titulo' => 'Editar usuario', 'datos' => $usuario ,'cajas' =>$cajas , 'roles' =>$roles];  

        echo view('header');
        echo view('usuarios/editar', $data); #mandamos la informacion a la vista usuarios.php
        echo view('footer');

    }
  
    function actualizar(){

       $this->usuarios->update( $this->request->getPost('id'), [
        'usuario' => $this->request->getPost('usuario'),
         'nombre' => $this->request->getPost('nombre'),
         'id_caja' => $this->request->getPost('id_caja'),
         'id_rol' => $this->request->getPost('id_rol')
        ]);
        
       return redirect()->to(base_url().'/usuarios');
    }

    function eliminar($id){

        $this->usuarios->update($id, ['activo' => 0]);
         
        return redirect()->to(base_url().'/usuarios');
     }

     
    function eliminadas($activo =0){
        $usuarios = $this->usuarios->where('activo', $activo)->findAll();   #consulta para traer todas las usuarios activas, en la misma linea se ejecuta
        
        $data = ['titulo' => 'Usuarios eliminadas', 'datos' => $usuarios];

        echo view('header');
        echo view('usuarios/eliminadas', $data); #mandamos la informacion a la vista usuarios.php
        echo view('footer');

    }

    function reingresar($id){

        $this->usuarios->update($id, ['activo' => 1]);
         
        return redirect()->to(base_url().'/usuarios');
     }

    function login(){
        echo view('login'); 
    }

    function valida(){
        
        if($this->request->getMethod() == 'post'){

            $usuario = $this->request->getPost('usuario');
            $password = $this->request->getPost('password');

            $datosUsuario= $this->usuarios->where('usuario', $usuario)->first();

            $mensaje="";

            if($datosUsuario!=null){

                if(password_verify($password, $datosUsuario['password'])){

                    $datosSesion=[
                        'id_usuario' => $datosUsuario['id'], 
                        'nombre' => $datosUsuario['nombre'],
                        'id_caja' => $datosUsuario['id_caja'],
                        'id_rol' => $datosUsuario['id_rol'],   
                    
                    ];

                    $session = session();
                    $session->set($datosSesion);

                    return redirect()->to(base_url() .'/configuracion');

                }else{
                    $data['error']="las contraseñas no coinciden";
                    echo view('login', $data);
                }

            }else{
                $data['error']="El usuario no existe";
                echo view('login', $data);
            }


        }
    }

    public function logout() {
        $session = session();
        $session->destroy();
        return redirect()->to(base_url());
    }
    
    public function cambia_password() {

        $session = session();

        $usuario = $this->usuarios->where('id', $session->id_usuario)->first();

        $data = ['titulo' => 'Cambiar contraseña', 'usuario' =>$usuario];

        echo view('header');
        echo view('usuarios/cambia_password', $data); #mandamos la informacion a la vista usuarios.php
        echo view('footer');


    }

    public function actualiza_password() {
  
        if($this->request->getMethod() == 'post' && $this->request->getPost('password')== $this->request->getPost('confirma') ){

            $session = session();
            $idUsuario = $session->id_usuario;

            $hash= password_hash($this->request->getPost('password') , PASSWORD_DEFAULT);
    
           $this->usuarios->update(
             $idUsuario, 
             [
                'password' => $hash
             ]);
    
             $data = ['titulo' => 'Cambiar contraseña', 'mensaje' => 'contraseña cambiada'];
    
             echo view('header');
             echo view('usuarios/cambia_password', $data); #mandamos la informacion a la vista usuarios.php
             echo view('footer');
           }else{
            $data = ['titulo' => 'Cambiar contraseña', 'mensaje' => 'Error al actualizar contraseña'];
    
            echo view('header');
            echo view('usuarios/cambia_password', $data); #mandamos la informacion a la vista usuarios.php
            echo view('footer');
           

           }
        
            
    }
}
