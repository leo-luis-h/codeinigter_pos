<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\CajasModel;

class Cajas extends BaseController
{

    protected $cajas;

    public function __construct(){
        $this->cajas = new CajasModel();
    }

    function index($activo =1){
        $cajas = $this->cajas->where('activo', $activo)->findAll();   #consulta para traer todas las cajas activas, en la misma linea se ejecuta
        
        $data = ['titulo' => 'Cajas', 'datos' => $cajas];

        echo view('header');
        echo view('cajas/cajas', $data); #mandamos la informacion a la vista cajas.php
        echo view('footer');

    }
    

    function nuevo(){

        $data = ['titulo' => 'Agregar cajas'];

        echo view('header');
        echo view('cajas/nuevo', $data); #mandamos la informacion a la vista cajas.php
        echo view('footer');

    }
  
    function insertar(){
       if($this->request->getMethod() == 'post' && $this->validate(['numero_caja' => 'required', 'nombre' => 'required'])){
       $this->cajas->save([
        'numero_caja' => $this->request->getPost('numero_caja'), 
        'nombre' => $this->request->getPost('nombre'),
        'nombre' => $this->request->getPost('nombre'),
        'folio' => $this->request->getPost('folio'),
        'activo' => 1,
       ]);
       return redirect()->to(base_url().'/cajas');
       }else{
        $data = ['titulo' => 'Agregar unidad', 'validation' =>$this->validation ];

        echo view('header');
        echo view('cajas/nuevo', $data); #mandamos la informacion a la vista cajas.php
        echo view('footer');
       }
       
    }


    function editar($id){
        $unidad = $this->cajas->where('id', $id)->first(); #first busca el primer registro
        $data = ['titulo' => 'Editar unidad', 'datos' => $unidad];  

        echo view('header');
        echo view('cajas/editar', $data); #mandamos la informacion a la vista cajas.php
        echo view('footer');

    }
  
    function actualizar(){

       $this->cajas->update(
       $this->request->getPost('id'),[
        'numero_caja' => $this->request->getPost('numero_caja'),
        'nombre' => $this->request->getPost('nombre'), 
        'folio' => $this->request->getPost('folio')
       
       ]);
        
       return redirect()->to(base_url().'/cajas');
    }

    function eliminar($id){

        $this->cajas->update($id, ['activo' => 0]);
         
        return redirect()->to(base_url().'/cajas');
     }

     
    function eliminadas($activo =0){
        $cajas = $this->cajas->where('activo', $activo)->findAll();   #consulta para traer todas las cajas activas, en la misma linea se ejecuta
        
        $data = ['titulo' => 'Cajas eliminadas', 'datos' => $cajas];

        echo view('header');
        echo view('cajas/eliminadas', $data); #mandamos la informacion a la vista cajas.php
        echo view('footer');

    }

    function reingresar($id){

        $this->cajas->update($id, ['activo' => 1]);
         
        return redirect()->to(base_url().'/cajas');
     }



    
}
