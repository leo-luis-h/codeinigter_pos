<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\RolesModel;

class Roles extends BaseController
{

    protected $roles;

    public function __construct(){
        $this->roles = new RolesModel();
    }

    function index($activo =1){
        $roles = $this->roles->where('activo', $activo)->findAll();   #consulta para traer todas las roles activas, en la misma linea se ejecuta
        
        $data = ['titulo' => 'Roles', 'datos' => $roles];

        echo view('header');
        echo view('roles/roles', $data); #mandamos la informacion a la vista roles.php
        echo view('footer');

    }
    

    function nuevo(){

        $data = ['titulo' => 'Agregar Rol'];

        echo view('header');
        echo view('roles/nuevo', $data); #mandamos la informacion a la vista roles.php
        echo view('footer');

    }
  
    function insertar(){
       if($this->request->getMethod() == 'post' && $this->validate(['nombre' => 'required'])){
       $this->roles->save(['nombre' => $this->request->getPost('nombre')]);
       return redirect()->to(base_url().'/roles');
       }else{
        $data = ['titulo' => 'Agregar Rol', 'validation' =>$this->validation ];

        echo view('header');
        echo view('roles/nuevo', $data); #mandamos la informacion a la vista roles.php
        echo view('footer');
       }
       
    }


    function editar($id){
        $roles = $this->roles->where('id', $id)->first(); #first busca el primer registro
        $data = ['titulo' => 'Editar Rol', 'datos' => $roles];  

        echo view('header');
        echo view('roles/editar', $data); #mandamos la informacion a la vista roles.php
        echo view('footer');

    }
  
    function actualizar(){

       $this->roles->update( $this->request->getPost('id'), ['nombre' => 
       $this->request->getPost('nombre')]);
        
       return redirect()->to(base_url().'/roles');
    }

    function eliminar($id){

        $this->roles->update($id, ['activo' => 0]);
         
        return redirect()->to(base_url().'/roles');
     }

     
    function eliminadas($activo =0){
        $roles = $this->roles->where('activo', $activo)->findAll();   #consulta para traer todas las roles activas, en la misma linea se ejecuta
        
        $data = ['titulo' => 'Roles eliminadas', 'datos' => $roles];

        echo view('header');
        echo view('roles/eliminadas', $data); #mandamos la informacion a la vista roles.php
        echo view('footer');

    }

    function reingresar($id){

        $this->roles->update($id, ['activo' => 1]);
         
        return redirect()->to(base_url().'/roles');
     }



    
}
