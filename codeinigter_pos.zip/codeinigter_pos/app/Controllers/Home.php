<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        echo view('header'); #layauts
        echo view('tables');  #layauts
        echo view('footer');  #layauts
    }
}
