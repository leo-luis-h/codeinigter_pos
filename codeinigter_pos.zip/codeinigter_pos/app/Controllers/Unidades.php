<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\UnidadesModel;

class Unidades extends BaseController
{

    protected $unidades;

    public function __construct(){
        $this->unidades = new UnidadesModel();
    }

    function index($activo =1){
        $unidades = $this->unidades->where('activo', $activo)->findAll();   #consulta para traer todas las unidades activas, en la misma linea se ejecuta
        
        $data = ['titulo' => 'Unidades', 'datos' => $unidades];

        echo view('header');
        echo view('unidades/unidades', $data); #mandamos la informacion a la vista unidades.php
        echo view('footer');

    }
    

    function nuevo(){

        $data = ['titulo' => 'Agregar unidad'];

        echo view('header');
        echo view('unidades/nuevo', $data); #mandamos la informacion a la vista unidades.php
        echo view('footer');

    }
  
    function insertar(){
       if($this->request->getMethod() == 'post' && $this->validate(['nombre' => 'required', 'nombre_corto' => 'required'])){
       $this->unidades->save([
        'nombre' => $this->request->getPost('nombre'), 
        'nombre_corto' => $this->request->getPost('nombre_corto')]);
       return redirect()->to(base_url().'/unidades');
       }else{
        $data = ['titulo' => 'Agregar unidad', 'validation' =>$this->validation ];

        echo view('header');
        echo view('unidades/nuevo', $data); #mandamos la informacion a la vista unidades.php
        echo view('footer');
       }
       
    }


    function editar($id){
        $unidad = $this->unidades->where('id', $id)->first(); #first busca el primer registro
        $data = ['titulo' => 'Editar unidad', 'datos' => $unidad];  

        echo view('header');
        echo view('unidades/editar', $data); #mandamos la informacion a la vista unidades.php
        echo view('footer');

    }
  
    function actualizar(){

       $this->unidades->update( $this->request->getPost('id'), 
       ['nombre' =>  $this->request->getPost('nombre'), 
       'nombre_corto' =>   $this->request->getPost('nombre_corto')]);
        
       return redirect()->to(base_url().'/unidades');
    }

    function eliminar($id){

        $this->unidades->update($id, ['activo' => 0]);
         
        return redirect()->to(base_url().'/unidades');
     }

     
    function eliminadas($activo =0){
        $unidades = $this->unidades->where('activo', $activo)->findAll();   #consulta para traer todas las unidades activas, en la misma linea se ejecuta
        
        $data = ['titulo' => 'Unidades eliminadas', 'datos' => $unidades];

        echo view('header');
        echo view('unidades/eliminadas', $data); #mandamos la informacion a la vista unidades.php
        echo view('footer');

    }

    function reingresar($id){

        $this->unidades->update($id, ['activo' => 1]);
         
        return redirect()->to(base_url().'/unidades');
     }



    
}
