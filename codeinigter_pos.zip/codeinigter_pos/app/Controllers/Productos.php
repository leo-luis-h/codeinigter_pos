<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ProductosModel;
use App\Models\UnidadesModel;
use App\Models\CategoriasModel;

class Productos extends BaseController{

    protected $productos;

    public function __construct(){
        $this->productos = new ProductosModel();

        $this->unidades = new UnidadesModel();
        $this->categorias = new CategoriasModel();
    }

    function index($activo =1){
        $productos = $this->productos->where('activo', $activo)->findAll();   #consulta para traer todas las productos activas, en la misma linea se ejecuta
       

        $data = ['titulo' => 'productos', 'datos' => $productos];

        echo view('header');
        echo view('productos/productos', $data); #mandamos la informacion a la vista productos.php
        echo view('footer');

    }
    

    function nuevo(){

        
        $unidades = $this->unidades->where('activo', 1)->findAll(); 
        $categorias = $this->categorias->where('activo', 1)->findAll();
        

        $data = ['titulo' => 'Agregar productos', 'categorias'=>$categorias , 'unidades'=>$unidades];

        echo view('header');
        echo view('productos/nuevo', $data); #mandamos la informacion a la vista productos.php
        echo view('footer');

    }
  
    function insertar(){
       if($this->request->getMethod() == 'post'){
       $this->productos->save([
       'codigo' => $this->request->getPost('codigo'), 
       'nombre' =>  $this->request->getPost('nombre'),
       'precio_venta' =>  $this->request->getPost('precio_venta'),
       'prec_compra' =>  $this->request->getPost('prec_compra'),
       'stock_minimo' =>  $this->request->getPost('stock_minimo'),
       'inventariable' =>  $this->request->getPost('inventariable'),
       'id_unidad' =>  $this->request->getPost('id_unidad'),
       'id_categoria' =>  $this->request->getPost('id_categoria'),
       ]);
       return redirect()->to(base_url().'/productos');
       }
       else{
        $data = ['titulo' => 'Agregar productos', 'validation' =>$this->validation,  ];

        echo view('header');
        echo view('productos/nuevo', $data); #mandamos la informacion a la vista productos.php
        echo view('footer');
       }
       
    }


    function editar($id){

        $unidades = $this->unidades->where('activo', 1)->findAll(); 
        $categorias = $this->categorias->where('activo', 1)->findAll();
        
        $productos = $this->productos->where('id', $id)->first(); #first busca el primer registro
        $data = ['titulo' => 'Editar producto', 'producto' => $productos , 'categorias'=>$categorias , 'unidades'=> $unidades,'productos' => $productos ];  

        echo view('header');
        echo view('productos/editar', $data); #mandamos la informacion a la vista productos.php
        echo view('footer');

    }
  
    function actualizar(){
     
   
        $this->productos->update($this->request->getPost('id'),
        [
        'codigo' => $this->request->getPost('codigo'), 
        'nombre' =>  $this->request->getPost('nombre'),
        'precio_venta' =>  $this->request->getPost('precio_venta'),
        'prec_compra' =>  $this->request->getPost('prec_compra'),
        'stock_minimo' =>  $this->request->getPost('stock_minimo'),
        'inventariable' =>  $this->request->getPost('inventariable'),
        'id_unidad' =>  $this->request->getPost('id_unidad'),
        'id_categoria' =>  $this->request->getPost('id_categoria'),
        ]);
      
        
       return redirect()->to(base_url().'/productos');
    }

    function eliminar($id){

        $this->productos->update($id, ['activo' => 0]);
         
        return redirect()->to(base_url().'/productos');
     }

     
    function eliminadas($activo =0){
        $productos = $this->productos->where('activo', $activo)->findAll();   #consulta para traer todas las productos activas, en la misma linea se ejecuta
        
        $data = ['titulo' => 'productos eliminadas', 'datos' => $productos];

        echo view('header');
        echo view('productos/eliminadas', $data); #mandamos la informacion a la vista productos.php
        echo view('footer');

    }

    function reingresar($id){

        $this->productos->update($id, ['activo' => 1]);
         
        return redirect()->to(base_url().'/productos');
     }



    
}
