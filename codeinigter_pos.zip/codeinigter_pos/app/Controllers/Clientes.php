<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ClientesModel;


class Clientes extends BaseController{

    protected $clientes;

    public function __construct(){
        $this->clientes = new ClientesModel();

    }

    function index($activo =1){
        $clientes = $this->clientes->where('activo', $activo)->findAll();   #consulta para traer todas las clientes activas, en la misma linea se ejecuta
       

        $data = ['titulo' => 'clientes', 'datos' => $clientes];

        echo view('header');
        echo view('clientes/clientes', $data); #mandamos la informacion a la vista clientes.php
        echo view('footer');

    }
    

    function nuevo(){

        $data = ['titulo' => 'Agregar clientes'];

        echo view('header');
        echo view('clientes/nuevo', $data); #mandamos la informacion a la vista clientes.php
        echo view('footer');

    }
  
    function insertar(){
       if($this->request->getMethod() == 'post'){
       $this->clientes->save([
       'nombre' =>  $this->request->getPost('nombre'),
       'direccion' =>  $this->request->getPost('direccion'),
       'telefono' =>  $this->request->getPost('telefono'),
       'correo' =>  $this->request->getPost('correo'),
       ]);
       return redirect()->to(base_url().'/clientes');
       }
       else{
        $data = ['titulo' => 'Agregar clientes', 'validation' =>$this->validation,  ];

        echo view('header');
        echo view('clientes/nuevo', $data); #mandamos la informacion a la vista clientes.php
        echo view('footer');
       }
       
    }


    function editar($id){

        
        
        $clientes = $this->clientes->where('id', $id)->first(); #first busca el primer registro
        $data = ['titulo' => 'Editar cliente', 'cliente' => $clientes ,'clientes' => $clientes ];  
  

        echo view('header');
        echo view('clientes/editar', $data); #mandamos la informacion a la vista clientes.php
        echo view('footer');

    }
  
    function actualizar(){
     
   
        $this->clientes->update($this->request->getPost('id'),
        [
            'nombre' =>  $this->request->getPost('nombre'),
            'direccion' =>  $this->request->getPost('direccion'),
            'telefono' =>  $this->request->getPost('telefono'),
            'correo' =>  $this->request->getPost('correo'),
        ]);
      
        
       return redirect()->to(base_url().'/clientes');
    }

    function eliminar($id){

        $this->clientes->update($id, ['activo' => 0]);
         
        return redirect()->to(base_url().'/clientes');
     }

     
    function eliminadas($activo =0){
        $clientes = $this->clientes->where('activo', $activo)->findAll();   #consulta para traer todas las clientes activas, en la misma linea se ejecuta
        
        $data = ['titulo' => 'clientes eliminadas', 'datos' => $clientes];

        echo view('header');
        echo view('clientes/eliminadas', $data); #mandamos la informacion a la vista clientes.php
        echo view('footer');

    }

    function reingresar($id){

        $this->clientes->update($id, ['activo' => 1]);
         
        return redirect()->to(base_url().'/clientes');
     }



    
}
