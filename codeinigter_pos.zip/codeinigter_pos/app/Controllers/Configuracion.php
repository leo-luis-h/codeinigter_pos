<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\ConfiguracionModel;

class Configuracion extends BaseController
{

    protected $configuracion;

    public function __construct(){
        $this->configuracion = new ConfiguracionModel();
    }

    function index($activo =1){
        $nombre = $this->configuracion->where('nombre', 'tienda_nombre')->first();   #consulta para traer todas las configuracion activas, en la misma linea se ejecuta
        $rfc = $this->configuracion->where('nombre', 'tienda_rfc')->first();
        $telefono = $this->configuracion->where('nombre', 'tienda_telefono')->first();
        $email = $this->configuracion->where('nombre', 'tienda_email')->first();
        $direccion = $this->configuracion->where('nombre', 'tienda_direccion')->first();
        $leyenda = $this->configuracion->where('nombre', 'tienda_leyenda')->first();

        $data = ['titulo' => 'Configuracion' , 'nombre' => $nombre, 'rfc' => $rfc,'telefono' => $telefono,'email' => $email,'direccion' => $direccion, 'leyenda' => $leyenda];

        echo view('header');
        echo view('configuracion/configuracion', $data); #mandamos la informacion a la vista configuracion.php
        echo view('footer');

    }

    function editar($id){
        $unidad = $this->configuracion->where('id', $id)->first(); #first busca el primer registro
        $data = ['titulo' => 'Editar unidad', 'datos' => $unidad];  

        echo view('header');
        echo view('configuracion/editar', $data); #mandamos la informacion a la vista configuracion.php
        echo view('footer');

    }
  
    function actualizar(){

       $this->configuracion->whereIn('nombre', ['tienda_nombre'])->set(['valor' => 
       $this->request->getPost('tienda_nombre')])->update();  
       
       $this->configuracion->whereIn('nombre', ['tienda_rfc'])->set(['valor' => 
       $this->request->getPost('tienda_rfc')])->update();  

       $this->configuracion->whereIn('nombre', ['tienda_telefono'])->set(['valor' => 
       $this->request->getPost('tienda_telefono')])->update();  

       $this->configuracion->whereIn('nombre', ['tienda_email'])->set(['valor' => 
       $this->request->getPost('tienda_email')])->update();  

       $this->configuracion->whereIn('nombre', ['tienda_direccion'])->set(['valor' => 
       $this->request->getPost('tienda_direccion')])->update(); 

       $this->configuracion->whereIn('nombre', ['tienda_leyenda'])->set(['valor' => 
       $this->request->getPost('tienda_leyenda')])->update(); 

       return redirect()->to(base_url().'/configuracion');
    }



    
}
